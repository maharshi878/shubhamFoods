import React from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import IntroSection from '@/components/IntroSection';
import CompanyAboutSection from '@/components/CompanyAboutSection';
import ProcessSection from '@/components/ProcessSection';
import ProductsOverviewSection from '@/components/ProductsOverviewSection';
import ProductDetailsSection from '@/components/ProductDetailsSection';
import B2BSection from '@/components/B2BSection';
import Footer from '@/components/Footer';

const Index: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <IntroSection />
        <CompanyAboutSection />
        <ProcessSection />
        <ProductsOverviewSection />
        <ProductDetailsSection />
        <B2BSection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;




