import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ScrollReveal from '@/components/ScrollReveal';
import B2BSection from '@/components/B2BSection';
import { Thermometer, Package, Truck, Clock, Shield, CheckCircle2 } from 'lucide-react';

const processSteps = [
  {
    step: '01',
    title: 'Raw Material Preparation',
    desc: 'Vegetables and legumes are cleaned, peeled where required, and cut to target dimensions for uniform frying.',
  },
  {
    step: '02',
    title: 'Blanching',
    desc: 'Brief heat treatment deactivates enzymes that cause browning and off-flavors during frying.',
  },
  {
    step: '03',
    title: 'Vacuum Frying',
    desc: 'Product is fried under low pressure — significantly reducing the boiling point of water and oil. This preserves color, nutrients, and creates a crisp texture with lower oil absorption than conventional frying.',
  },
  {
    step: '04',
    title: 'Centrifugal De-oiling',
    desc: 'Excess surface oil is removed by centrifugal spinning immediately post-fry for a cleaner finish.',
  },
  {
    step: '05',
    title: 'Seasoning (Optional)',
    desc: 'Plain or seasoned variants available. Spice blends applied under controlled tumbling for even coating.',
  },
  {
    step: '06',
    title: 'Packaging',
    desc: 'Nitrogen-flushed packaging for extended shelf life. Bulk, retail, and private-label formats available.',
  },
];

const specs = [
  { icon: Thermometer, label: 'Process Temp', value: 'Below 120°C vacuum frying' },
  { icon: Clock, label: 'Shelf Life', value: 'Up to 12 months sealed' },
  { icon: Package, label: 'Formats', value: 'Plain, seasoned, private label' },
  { icon: Truck, label: 'MOQ', value: 'Negotiable — B2B enquiry' },
  { icon: Shield, label: 'Quality', value: 'Batch oil and moisture checks' },
  { icon: CheckCircle2, label: 'Suitable For', value: 'Snack retail, horeca, export' },
];

const products = [
  { name: 'Vacuum Fried Garlic', desc: 'Crisp garlic chips with concentrated flavor. Lower oil content than conventional fried garlic.' },
  { name: 'Vacuum Fried Okra', desc: 'Delicate crunch with preserved green color. Popular in health-forward snack applications.' },
  { name: 'Vacuum Fried Potatoes', desc: 'Light, crisp potato slices with significantly reduced oil uptake versus standard frying.' },
  { name: 'Vacuum Fried Chickpeas', desc: 'High-protein snack base. Crisp texture suitable for seasoned and plain formats.' },
  { name: 'Vacuum Fried Kidney Beans', desc: 'Firm, crunchy texture. Suitable for trail mix, snack blends, and retail packs.' },
  { name: 'Vacuum Fried Sweet Potatoes', desc: 'Naturally sweet flavor profile with vibrant color retention from low-temperature frying.' },
  { name: 'Vacuum Fried Banana', desc: 'Crisp banana chips with natural sweetness. Available plain or lightly seasoned.' },
];

const VacuumFried: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>

        {/* Hero */}
        <section className="relative min-h-[60vh] flex items-center justify-center pt-32 pb-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
          <div className="container relative z-10 px-6 text-center">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Snack & Ingredient Line</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h1 className="text-5xl md:text-7xl font-bold font-display mb-6">
                Vacuum <span className="text-gradient">Fried Products</span>
              </h1>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Low-pressure frying that delivers crisp texture, vibrant color, and
                reduced oil content — across garlic, vegetables, and legumes for
                snack and ingredient applications.
              </p>
            </ScrollReveal>
          </div>
        </section>

        {/* Product variants */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-6xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-4">Product Range</h2>
              </ScrollReveal>
              <ScrollReveal delay={0.1}>
                <p className="section-subtitle text-center mx-auto mb-16">
                  Seven vacuum fried products across garlic, vegetables, legumes, and fruit.
                </p>
              </ScrollReveal>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product, i) => (
                  <ScrollReveal key={product.name} delay={i * 0.07}>
                    <div className="glass-card p-6 h-full">
                      <h3 className="font-display text-xl font-semibold mb-3 text-gradient">{product.name}</h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">{product.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="py-24 bg-secondary/10">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-4">How It's Made</h2>
              </ScrollReveal>
              <ScrollReveal delay={0.1}>
                <p className="section-subtitle text-center mx-auto mb-16">
                  Vacuum frying operates at significantly lower temperatures than
                  conventional frying — protecting color, flavor, and nutritional value.
                </p>
              </ScrollReveal>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {processSteps.map((step, i) => (
                  <ScrollReveal key={step.step} delay={i * 0.08}>
                    <div className="glass-card p-6">
                      <span className="text-4xl font-bold text-primary/30 font-display">{step.step}</span>
                      <h3 className="text-lg font-semibold mt-2 mb-2">{step.title}</h3>
                      <p className="text-muted-foreground text-sm">{step.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Specs */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-16">Product Specifications</h2>
              </ScrollReveal>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {specs.map((spec, i) => (
                  <ScrollReveal key={spec.label} delay={i * 0.08}>
                    <div className="glass-card p-6 text-center">
                      <spec.icon className="w-7 h-7 text-primary mx-auto mb-3" />
                      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">{spec.label}</p>
                      <p className="text-sm font-semibold">{spec.value}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        <B2BSection />
      </main>
      <Footer />
    </div>
  );
};

export default VacuumFried;