import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ScrollReveal from '@/components/ScrollReveal';
import B2BSection from '@/components/B2BSection';
import { Thermometer, Package, Truck, Clock, Shield, CheckCircle2 } from 'lucide-react';

const processSteps = [
  {
    step: '01',
    title: 'Post-Pipeline Entry',
    desc: 'Peeled, washed, and inspected cloves enter the roasting line after the shared garlic processing pipeline.',
  },
  {
    step: '02',
    title: 'Roasting',
    desc: 'Cloves are roasted in controlled batches to develop the characteristic caramelized flavor profile without burning or uneven browning.',
  },
  {
    step: '03',
    title: 'Cooling',
    desc: 'Roasted cloves are cooled rapidly to halt carryover cooking and stabilize texture before coating.',
  },
  {
    step: '04',
    title: 'Masala Blending',
    desc: 'Spice blends are prepared in-house. Intensity and composition are adjustable per buyer specification.',
  },
  {
    step: '05',
    title: 'Coating',
    desc: 'Masala is applied under controlled tumbling to ensure even, consistent coating across all cloves.',
  },
  {
    step: '06',
    title: 'Packaging',
    desc: 'Packed in snack pouches, jars, or foodservice bulk formats. Private label and custom spice profiles available.',
  },
];

const specs = [
  { icon: Thermometer, label: 'Storage', value: 'Cool, dry — ambient stable' },
  { icon: Clock, label: 'Shelf Life', value: 'Up to 9 months sealed' },
  { icon: Package, label: 'Formats', value: 'Snack pouches, jars, bulk' },
  { icon: Truck, label: 'MOQ', value: 'Negotiable — B2B enquiry' },
  { icon: Shield, label: 'Quality', value: 'Batch roast + coating checks' },
  { icon: CheckCircle2, label: 'Suitable For', value: 'Retail snack, gifting, horeca' },
];

const highlights = [
  {
    title: 'Custom Spice Profiles',
    desc: 'Spice intensity and blend composition can be adjusted per channel — mild for retail, bold for foodservice.',
  },
  {
    title: 'Private Label Ready',
    desc: 'Supplied unbranded for repackers and private label buyers. Custom pack sizes and formats on request.',
  },
  {
    title: 'Snack & Ingredient Use',
    desc: 'Suitable as a ready-to-eat snack or as a flavored garlic ingredient for food manufacturing applications.',
  },
];

const RoastedMasala: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>

        {/* Hero */}
        <section className="relative min-h-[60vh] flex items-center justify-center pt-32 pb-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
          <div className="container relative z-10 px-6 text-center">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Flavored Snack Line</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h1 className="text-5xl md:text-7xl font-bold font-display mb-6">
                Roasted <span className="text-gradient">Masala Garlic</span>
              </h1>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Whole roasted garlic cloves with controlled masala coating —
                developed for retail snacking, gifting formats, and
                foodservice applications requiring a bold, ready-to-eat garlic product.
              </p>
            </ScrollReveal>
          </div>
        </section>

        {/* Highlights */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-16">Product Highlights</h2>
              </ScrollReveal>
              <div className="grid md:grid-cols-3 gap-6">
                {highlights.map((item, i) => (
                  <ScrollReveal key={item.title} delay={i * 0.1}>
                    <div className="glass-card p-8 h-full">
                      <h3 className="font-display text-xl font-semibold mb-4 text-gradient">{item.title}</h3>
                      <p className="text-muted-foreground leading-relaxed text-sm">{item.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="py-24 bg-secondary/10">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-4">How It's Made</h2>
              </ScrollReveal>
              <ScrollReveal delay={0.1}>
                <p className="section-subtitle text-center mx-auto mb-16">
                  Roasting and masala coating are carried out in controlled batches
                  to ensure consistency across flavor, texture, and appearance.
                </p>
              </ScrollReveal>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {processSteps.map((step, i) => (
                  <ScrollReveal key={step.step} delay={i * 0.08}>
                    <div className="glass-card p-6">
                      <span className="text-4xl font-bold text-primary/30 font-display">{step.step}</span>
                      <h3 className="text-lg font-semibold mt-2 mb-2">{step.title}</h3>
                      <p className="text-muted-foreground text-sm">{step.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Specs */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-16">Product Specifications</h2>
              </ScrollReveal>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {specs.map((spec, i) => (
                  <ScrollReveal key={spec.label} delay={i * 0.08}>
                    <div className="glass-card p-6 text-center">
                      <spec.icon className="w-7 h-7 text-primary mx-auto mb-3" />
                      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">{spec.label}</p>
                      <p className="text-sm font-semibold">{spec.value}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        <B2BSection />
      </main>
      <Footer />
    </div>
  );
};

export default RoastedMasala;