import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BlackGarlicSection from '@/components/BlackGarlicSection';
import AboutSection from '@/components/AboutSection';
import BenefitsSection from '@/components/BenefitsSection';
import ComparisonSection from '@/components/ComparisonSection';
import NutritionSection from '@/components/NutritionSection';
import ResearchSection from '@/components/ResearchSection';
import RecipesSection from '@/components/RecipesSection';
import WhyUsSection from '@/components/WhyUsSection';
import B2BSection from '@/components/B2BSection';

const BlackGarlic: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <BlackGarlicSection />
        <AboutSection />
        <BenefitsSection />
        <ComparisonSection />
        <NutritionSection />
        <ResearchSection />
        <RecipesSection />
        <WhyUsSection />
        <B2BSection />
      </main>
      <Footer />
    </div>
  );
};

export default BlackGarlic;
