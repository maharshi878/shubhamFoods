import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ScrollReveal from '@/components/ScrollReveal';
import B2BSection from '@/components/B2BSection';
import { Thermometer, Package, Truck, Clock, Shield, CheckCircle2 } from 'lucide-react';

const processSteps = [
  {
    step: '01',
    title: 'Post-Pipeline Entry',
    desc: 'Cloves arrive from the shared processing line - washed, centrifugally dried, colour sorted, and manually inspected.',
  },
  {
    step: '02',
    title: 'Grade Separation',
    desc: 'Cloves are separated by size and visual grade to meet customer specifications for uniformity.',
  },
  {
    step: '03',
    title: 'Chilling or Ambient Hold',
    desc: 'Depending on dispatch protocol, cloves are either chilled to near-zero or held at controlled ambient temperature.',
  },
  {
    step: '04',
    title: 'Packaging',
    desc: 'Packed in food-grade pouches or bulk cartons as per buyer requirement - retail, horeca, or processor formats.',
  },
];

const specs = [
  { icon: Thermometer, label: 'Storage', value: '0-4 C chilled or ambient' },
  { icon: Clock, label: 'Shelf Life', value: 'Up to 12 months frozen' },
  { icon: Package, label: 'Pack Formats', value: 'Bulk cartons, retail pouches' },
  { icon: Truck, label: 'MOQ', value: 'Negotiable - B2B enquiry' },
  { icon: Shield, label: 'Quality', value: 'Colour sorted + manually inspected' },
  { icon: CheckCircle2, label: 'Suitable For', value: 'Horeca, processors, repackers' },
];

const PeeledGarlic: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>

        {/* Hero */}
        <section className="relative min-h-[60vh] flex items-center justify-center pt-32 pb-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
          <div className="container relative z-10 px-6 text-center">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Garlic Ingredients</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h1 className="text-5xl md:text-7xl font-bold font-display mb-6">
                Peeled <span className="text-gradient">Frozen Garlic</span>
              </h1>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Clean, consistently processed peeled garlic cloves ready for horeca kitchens,
                food processors, and bulk repackers requiring reliable garlic inputs at scale.
              </p>
            </ScrollReveal>
          </div>
        </section>

        {/* Process */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-4">How It's Made</h2>
              </ScrollReveal>
              <ScrollReveal delay={0.1}>
                <p className="section-subtitle text-center mx-auto mb-16">
                  After the shared garlic processing pipeline, peeled garlic goes through
                  final grading and packaging steps.
                </p>
              </ScrollReveal>
              <div className="grid md:grid-cols-2 gap-6">
                {processSteps.map((step, i) => (
                  <ScrollReveal key={step.step} delay={i * 0.1}>
                    <div className="glass-card p-6">
                      <span className="text-4xl font-bold text-primary/30 font-display">{step.step}</span>
                      <h3 className="text-lg font-semibold mt-2 mb-2">{step.title}</h3>
                      <p className="text-muted-foreground text-sm">{step.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Specs */}
        <section className="py-24 bg-secondary/10">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-16">Product Specifications</h2>
              </ScrollReveal>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {specs.map((spec, i) => (
                  <ScrollReveal key={spec.label} delay={i * 0.08}>
                    <div className="glass-card p-6 text-center">
                      <spec.icon className="w-7 h-7 text-primary mx-auto mb-3" />
                      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">{spec.label}</p>
                      <p className="text-sm font-semibold">{spec.value}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        <B2BSection />
      </main>
      <Footer />
    </div>
  );
};

export default PeeledGarlic;
