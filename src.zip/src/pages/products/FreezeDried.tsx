import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ScrollReveal from '@/components/ScrollReveal';
import B2BSection from '@/components/B2BSection';
import { Thermometer, Package, Truck, Clock, Shield, CheckCircle2 } from 'lucide-react';

const processSteps = [
  {
    step: '01',
    title: 'Post-Pipeline Entry',
    desc: 'Peeled, washed, and inspected cloves enter the freeze-dry line after the shared processing pipeline.',
  },
  {
    step: '02',
    title: 'Pre-Freezing',
    desc: 'Cloves or slices are rapidly frozen to lock cellular structure and preserve volatile flavor compounds.',
  },
  {
    step: '03',
    title: 'Sublimation Drying',
    desc: 'Frozen product is placed in a vacuum chamber where ice converts directly to vapor — no liquid phase — retaining shape, color, and nutrition.',
  },
  {
    step: '04',
    title: 'Milling and Sizing',
    desc: 'Dried product is milled into granules, powder, or flakes depending on buyer specification.',
  },
  {
    step: '05',
    title: 'Moisture Check',
    desc: 'Final moisture content is verified per batch before packaging to ensure shelf stability.',
  },
  {
    step: '06',
    title: 'Packaging',
    desc: 'Sealed in moisture-barrier pouches or bulk containers. Custom cuts and private label available.',
  },
];

const specs = [
  { icon: Thermometer, label: 'Storage', value: 'Cool, dry — ambient stable' },
  { icon: Clock, label: 'Shelf Life', value: 'Up to 24 months sealed' },
  { icon: Package, label: 'Formats', value: 'Granules, powder, flakes, slices' },
  { icon: Truck, label: 'MOQ', value: 'Negotiable — B2B enquiry' },
  { icon: Shield, label: 'Quality', value: 'Batch moisture verified' },
  { icon: CheckCircle2, label: 'Suitable For', value: 'Seasoning, dry blends, retail' },
];

const products = [
  {
    name: 'Freeze Dried Garlic',
    desc: 'Concentrated garlic flavor in granule, powder, or flake form. Ideal for seasoning blends, instant foods, and food manufacturing.',
  },
  {
    name: 'Freeze Dried Banana',
    desc: 'Naturally sweet freeze dried banana slices and powder. Suitable for cereals, snack mixes, and health food applications.',
  },
];

const FreezeDried: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>

        {/* Hero */}
        <section className="relative min-h-[60vh] flex items-center justify-center pt-32 pb-16 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
          <div className="container relative z-10 px-6 text-center">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Dehydrated Products</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h1 className="text-5xl md:text-7xl font-bold font-display mb-6">
                Freeze <span className="text-gradient">Dried Products</span>
              </h1>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Low-temperature sublimation drying that preserves flavor, color, and nutrition
                with ambient-stable shelf life — supplied as garlic and banana in multiple formats.
              </p>
            </ScrollReveal>
          </div>
        </section>

        {/* Product variants */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-4xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-16">Product Variants</h2>
              </ScrollReveal>
              <div className="grid md:grid-cols-2 gap-6">
                {products.map((product, i) => (
                  <ScrollReveal key={product.name} delay={i * 0.1}>
                    <div className="glass-card p-8">
                      <h3 className="font-display text-2xl font-semibold mb-4 text-gradient">{product.name}</h3>
                      <p className="text-muted-foreground leading-relaxed">{product.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Process */}
        <section className="py-24 bg-secondary/10">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-4">How It's Made</h2>
              </ScrollReveal>
              <ScrollReveal delay={0.1}>
                <p className="section-subtitle text-center mx-auto mb-16">
                  Freeze drying preserves what conventional drying destroys —
                  flavor volatiles, cell structure, and nutritional density.
                </p>
              </ScrollReveal>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {processSteps.map((step, i) => (
                  <ScrollReveal key={step.step} delay={i * 0.08}>
                    <div className="glass-card p-6">
                      <span className="text-4xl font-bold text-primary/30 font-display">{step.step}</span>
                      <h3 className="text-lg font-semibold mt-2 mb-2">{step.title}</h3>
                      <p className="text-muted-foreground text-sm">{step.desc}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Specs */}
        <section className="py-24">
          <div className="container px-6">
            <div className="max-w-5xl mx-auto">
              <ScrollReveal>
                <h2 className="section-title text-center mb-16">Product Specifications</h2>
              </ScrollReveal>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {specs.map((spec, i) => (
                  <ScrollReveal key={spec.label} delay={i * 0.08}>
                    <div className="glass-card p-6 text-center">
                      <spec.icon className="w-7 h-7 text-primary mx-auto mb-3" />
                      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">{spec.label}</p>
                      <p className="text-sm font-semibold">{spec.value}</p>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </div>
        </section>

        <B2BSection />
      </main>
      <Footer />
    </div>
  );
};

export default FreezeDried;
