import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowDown, Briefcase } from 'lucide-react';
import ShaderAnimation from '@/components/ui/shader-animation';

const HeroSection: React.FC = () => {
  const { scrollY } = useScroll();

  const imageY = useTransform(scrollY, [0, 500], [0, 150]);
  const contentY = useTransform(scrollY, [0, 500], [0, 50]);
  const orbY = useTransform(scrollY, [0, 500], [0, -100]);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-8">
      <motion.div className="absolute inset-0 z-0" style={{ y: imageY }}>
        <ShaderAnimation className="absolute inset-0" />
      </motion.div>
      <motion.div className="absolute inset-0 z-[1]" style={{ y: orbY }}>
        <div className="absolute inset-0 bg-gradient-to-b from-background/75 via-background/84 to-background/92" />
      </motion.div>
      <div className="absolute bottom-0 left-0 right-0 h-32 z-[2] pointer-events-none"
        style={{ background: 'linear-gradient(to bottom, transparent, hsl(20 10% 6%))' }}
      />
      <motion.div className="container relative z-10 px-6" style={{ y: contentY }}>
        <div className="max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-block mb-8"
          >
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-bold tracking-tight mb-8"
          >
            <span className="text-white">From Farm to Finished Food Products</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-white max-w-3xl mx-auto mb-12 leading-relaxed"
          >
            Shubham Foods is a value-added garlic processing unit delivering consistent,
            quality-controlled products for both bulk and retail markets.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mb-16 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <a
              href="#products"
              className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground rounded-full font-medium text-lg transition-all duration-300 hover:shadow-[0_0_40px_hsl(38_90%_50%/0.4)] hover:scale-105"
            >
              Explore Products
              <ArrowDown className="w-5 h-5" />
            </a>
            <a
              href="/#bulk-enquiry"
              className="inline-flex items-center gap-3 px-8 py-4 glass-card rounded-full font-medium text-lg transition-all duration-300 hover:border-primary/40"
            >
              Bulk Enquiry
              <Briefcase className="w-5 h-5 text-primary" />
            </a>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;

