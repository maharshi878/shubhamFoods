import React from 'react';
import ScrollReveal from './ScrollReveal';
import { Landmark, Settings, CookingPot, FlaskConical } from 'lucide-react';

const BlackGarlicSection: React.FC = () => {
  return (
    <section id="black-garlic" className="py-24 relative">
      <div className="container px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">A Product by Shubham Foods</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h2 className="section-title mb-6">Black Garlic</h2>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="section-subtitle mx-auto">
                Black Garlic is produced through controlled fermentation of whole bulbs, resulting in a sweet,
                mellow profile valued in culinary applications and further food processing.
              </p>
            </ScrollReveal>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <ScrollReveal>
              <div className="glass-card p-8 h-full">
                <Landmark className="w-8 h-8 text-primary mb-5" />
                <h3 className="font-display text-2xl font-semibold mb-3">Controlled Fermentation</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Temperature, humidity, and duration are managed batch by batch to deliver consistent texture,
                  color, and flavor progression.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.1}>
              <div className="glass-card p-8 h-full">
                <CookingPot className="w-8 h-8 text-primary mb-5" />
                <h3 className="font-display text-2xl font-semibold mb-3">Culinary Value</h3>
                <p className="text-muted-foreground leading-relaxed">
                  The product offers umami depth, natural sweetness, and low pungency, making it useful in sauces,
                  marinades, condiments, and premium ready-to-eat formats.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.2}>
              <div className="glass-card p-8 h-full">
                <Settings className="w-8 h-8 text-primary mb-5" />
                <h3 className="font-display text-2xl font-semibold mb-3">Processing Utility</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Black Garlic can be supplied for direct culinary use or as an input for blends, spreads,
                  seasoning systems, and value-added formulations.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.3}>
              <div className="glass-card p-8 h-full border-l-4 border-l-primary">
                <FlaskConical className="w-8 h-8 text-primary mb-5" />
                <h3 className="font-display text-2xl font-semibold mb-3">Transparent Technical Framing</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Research and nutrition sections are presented as reference-oriented information, avoiding
                  exaggerated therapeutic claims while retaining process and composition clarity.
                </p>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BlackGarlicSection;
