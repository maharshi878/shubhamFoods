import React from 'react';
import ScrollReveal from './ScrollReveal';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="py-16 border-t border-border/30">
      <div className="container px-6">
        <div className="max-w-6xl mx-auto">
          <ScrollReveal>
            <div className="glass-card p-8 md:p-12 text-center mb-12 pointer-events-none">
              <div className="flex items-center justify-center gap-3 mb-4 pointer-events-auto">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <span className="text-primary-foreground font-display font-bold text-xl">SF</span>
                </div>
                <h3 className="font-display text-2xl font-semibold">Shubham Foods</h3>
              </div>

                <p className="text-muted-foreground max-w-xl mx-auto mb-8 pointer-events-auto">
                Committed to delivering consistent quality, authentic taste, and carefully processed food products.</p>

              <div className="h-px w-24 bg-border/40 mx-auto mb-8" />

              <div className="space-y-3 text-sm text-muted-foreground pointer-events-auto">
                <p className="font-medium text-foreground">Shubham Foods</p>
                <p>
                  Besides Zadeshwar Gram Panchayat,<br />
                  Zadeshwar, Dist. Bharuch (Gujarat)
                </p>
                <p>
                  <span className="font-medium">Mobile:</span>{' '}
                  <a href="tel:+919173891552" className="hover:text-primary">9173891552</a>
                  {' , '}
                  <a href="tel:+919265461216" className="hover:text-primary">9265461216</a>
                </p>
                <p>
                  <span className="font-medium">Email:</span>{' '}
                  <a href="mailto:68jmdave@gmail.com" className="hover:text-primary">68jmdave@gmail.com</a>
                  {' , '}
                  <a href="mailto:vnutrifoods@gmail.com" className="hover:text-primary">vnutrifoods@gmail.com</a>
                </p>
              </div>
            </div>
          </ScrollReveal>

          <div className="text-center text-sm text-muted-foreground">
            � 2026 Shubham Foods. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
