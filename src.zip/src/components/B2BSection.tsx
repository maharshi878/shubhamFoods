import React, { useState } from 'react';
import ScrollReveal from './ScrollReveal';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

type InquiryType = 'consumer' | 'bulk';

const B2BSection: React.FC = () => {
  const [inquiryType, setInquiryType] = useState<InquiryType>('consumer');

  return (
    <section id="bulk-enquiry" className="py-24 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-1/2 h-full bg-gradient-to-r from-primary/5 to-transparent" />
      <div className="container px-6 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Enquiry</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h2 className="section-title mb-6">Bulk &amp; Trade Enquiries</h2>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="section-subtitle mx-auto">
                Use one form for both consumer and trade requests. Select inquiry type to reveal the right level of detail.
              </p>
            </ScrollReveal>
          </div>

          <ScrollReveal delay={0.25}>
            <div className="glass-card p-7 md:p-10">
              <form className="space-y-6" onSubmit={(event) => event.preventDefault()}>
                <div>
                  <label htmlFor="inquiryType" className="text-sm font-medium text-foreground mb-2 block">
                    Inquiry Type
                  </label>
                  <select
                    id="inquiryType"
                    name="inquiryType"
                    value={inquiryType}
                    onChange={(event) => setInquiryType(event.target.value as InquiryType)}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  >
                    <option value="consumer">Consumer</option>
                    <option value="bulk">Bulk / B2B</option>
                  </select>
                </div>

                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="contactName" className="text-sm font-medium text-foreground mb-2 block">
                      Contact Name
                    </label>
                    <Input id="contactName" name="contactName" placeholder="Your name" />
                  </div>
                  <div>
                    <label htmlFor="contactPhone" className="text-sm font-medium text-foreground mb-2 block">
                      Contact Number
                    </label>
                    <Input id="contactPhone" name="contactPhone" placeholder="Phone / WhatsApp" />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-5">
                  <div>
                    <label htmlFor="contactEmail" className="text-sm font-medium text-foreground mb-2 block">
                      Email
                    </label>
                    <Input id="contactEmail" name="contactEmail" type="email" placeholder="name@company.com" />
                  </div>
                  <div>
                    <label htmlFor="location" className="text-sm font-medium text-foreground mb-2 block">
                      Location
                    </label>
                    <Input id="location" name="location" placeholder="City, State" />
                  </div>
                </div>

                {inquiryType === 'bulk' && (
                  <div className="space-y-6 rounded-xl border border-border/40 bg-secondary/20 p-5">
                    <div className="grid md:grid-cols-2 gap-5">
                      <div>
                        <label htmlFor="companyName" className="text-sm font-medium text-foreground mb-2 block">
                          Company Name
                        </label>
                        <Input id="companyName" name="companyName" placeholder="Registered business name" />
                      </div>
                      <div>
                        <label htmlFor="businessType" className="text-sm font-medium text-foreground mb-2 block">
                          Business Type
                        </label>
                        <select
                          id="businessType"
                          name="businessType"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                          defaultValue="Distributor"
                        >
                          <option>Distributor</option>
                          <option>Exporter</option>
                          <option>HoReCa</option>
                          <option>Retail</option>
                          <option>Other</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-5">
                      <div>
                        <label htmlFor="productsOfInterest" className="text-sm font-medium text-foreground mb-2 block">
                          Products of Interest
                        </label>
                        <Input
                          id="productsOfInterest"
                          name="productsOfInterest"
                          placeholder="Black Garlic, Peeled Garlic, Freeze Dried..."
                        />
                      </div>
                      <div>
                        <label htmlFor="monthlyQuantity" className="text-sm font-medium text-foreground mb-2 block">
                          Estimated Monthly Quantity
                        </label>
                        <Input id="monthlyQuantity" name="monthlyQuantity" placeholder="e.g. 500 kg / month" />
                      </div>
                    </div>
                  </div>
                )}

                <div>
                  <label htmlFor="message" className="text-sm font-medium text-foreground mb-2 block">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    className="min-h-[120px]"
                    placeholder={
                      inquiryType === 'bulk'
                        ? 'Share product specs, quantity expectations, and delivery timelines.'
                        : 'Tell us how we can help you.'
                    }
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-primary-foreground rounded-full font-medium text-base transition-all duration-300 hover:shadow-[0_0_40px_hsl(38_90%_50%/0.4)]"
                  >
                    Submit Enquiry
                  </button>
                </div>
              </form>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default B2BSection;




