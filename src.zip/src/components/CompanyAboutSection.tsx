import React from 'react';
import ScrollReveal from './ScrollReveal';
import { Factory, Hand, Layers, PackageCheck } from 'lucide-react';

const points = [
  {
    title: 'Local Sourcing Network',
    description:
      'We source garlic from regional growers and plan procurement around variety, maturity, and processing suitability.',
    icon: Factory,
  },
  {
    title: 'Mechanized + Manual Processing',
    description:
      'Our line combines equipment-led consistency with manual checks at key points for sorting and quality verification.',
    icon: Hand,
  },
  {
    title: 'Expansion-Ready Infrastructure',
    description:
      'The facility is set up to scale batches and support multi-product operations without compromising process discipline.',
    icon: Layers,
  },
  {
    title: 'Multiple Product Formats',
    description:
      'From raw and peeled to fermented and fried formats, we process garlic into products for culinary, retail, and industrial use.',
    icon: PackageCheck,
  },
];

const CompanyAboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 relative">
      <div className="container px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">About Shubham Foods</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h2 className="section-title mb-6">Processing-Centered Food Manufacturing</h2>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="section-subtitle mx-auto">
                We operate as a value-add processing company with a practical focus on input quality,
                process control, and reliable output across product categories.
              </p>
            </ScrollReveal>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {points.map((point, index) => {
              const Icon = point.icon;
              return (
                <ScrollReveal key={point.title} delay={index * 0.1}>
                  <div className="glass-card p-8 h-full">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-6">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="font-display text-2xl font-semibold mb-3">{point.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{point.description}</p>
                  </div>
                </ScrollReveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CompanyAboutSection;
