import React from 'react';
import ScrollReveal from './ScrollReveal';
import { motion } from 'framer-motion';
import {
  Tractor,
  Sun,
  Wind,
  Factory,
  Hand,
  Droplets,
  Fan,
  Palette,
  ScanSearch,
  Package,
} from 'lucide-react';

const steps = [
  { title: 'Local sourcing', desc: 'Garlic is procured from local supply clusters based on quality and seasonality.', icon: Tractor },
  { title: 'Sun drying', desc: 'Initial moisture balancing is carried out through controlled sun drying.', icon: Sun },
  { title: 'Tray drying', desc: 'Product is moved to tray dryers for uniform controlled dehydration.', icon: Wind },
  { title: 'Bulb breaker', desc: 'Bulbs are mechanically separated for downstream processing.', icon: Factory },
  { title: 'Peeling', desc: 'Peeling is performed through equipment and manual line checks.', icon: Hand },
  { title: 'Washing', desc: 'Cloves are washed to remove surface impurities and loose residues.', icon: Droplets },
  { title: 'Centrifugal drying', desc: 'Washed material is dried to target surface moisture levels.', icon: Fan },
  { title: 'Colour sorting', desc: 'Optical and visual sorting is done for appearance consistency.', icon: Palette },
  { title: 'Manual sorting', desc: 'Final hand sorting removes defects and non-conforming pieces.', icon: ScanSearch },
  { title: 'Packaging or further processing', desc: 'Lots are packed or moved to fermentation, roasting, freeze drying, or vacuum frying lines.', icon: Package },
];

const ProcessSection: React.FC = () => {
  return (
    <section id="process" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-primary/5 rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-primary/5 rounded-full" />
      </div>

      <div className="container px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Company Workflow</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h2 className="section-title mb-6">Processing Flow Across Product Lines</h2>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="section-subtitle mx-auto">
                Shared process stages are managed as a structured system before final packing or line-specific value addition.
              </p>
            </ScrollReveal>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <ScrollReveal key={step.title} delay={index * 0.06}>
                  <motion.div whileHover={{ scale: 1.02 }} className="glass-card p-7 h-full">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <span className="text-sm font-mono text-primary/70">{String(index + 1).padStart(2, '0')}</span>
                    </div>
                    <h3 className="font-display text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{step.desc}</p>
                  </motion.div>
                </ScrollReveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProcessSection;
