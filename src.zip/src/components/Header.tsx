import React from 'react';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useLanguage, Language } from '@/contexts/LanguageContext';

const Header: React.FC = () => {
  const { language, setLanguage } = useLanguage();

  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'EN' },
    { code: 'gu', label: 'GU' },
    { code: 'hi', label: 'HI' },
  ];

  const navItems = [
    { label: 'Home', href: '/' },
    { label: 'Black Garlic', href: '/products/black-garlic' },
    { label: 'Peeled Garlic', href: '/products/peeled-garlic' },
    { label: 'Freeze Dried', href: '/products/freeze-dried' },
    { label: 'Vacuum Fried', href: '/products/vacuum-fried' },
    { label: 'Roasted Masala', href: '/products/roasted-masala' },
    { label: 'Process', href: '/#process' },
    { label: 'B2B', href: '/#bulk-enquiry' },
    { label: 'Contact', href: '/#contact' },
  ];

  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 80);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{
        y: visible ? 0 : -20,
        opacity: visible ? 1 : 0,
        pointerEvents: visible ? 'auto' : 'none'
      }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-[9999] pointer-events-auto"
    >
      <div className="mx-auto max-w-7xl px-6 py-4">
        <div className="glass-card px-6 py-3 pointer-events-none">
          <div className="flex items-center justify-between gap-6 mb-3">
            <a
              href="#home"
              className="flex items-center gap-3 cursor-pointer pointer-events-auto"
            >
              <img src="/logo.png" alt="Shubham Foods" className="h-10 w-auto object-contain" />
              <div>
                <span className="font-display text-xl font-semibold block leading-tight">
                  Shubham Foods
                </span>
                <span className="text-xs text-muted-foreground hidden sm:block">
                  Garlic Products Manufacturer
                </span>
              </div>
            </a>

            <div className="flex items-center gap-1 bg-secondary/50 rounded-lg p-1 pointer-events-auto">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => setLanguage(lang.code)}
                  className={`language-btn cursor-pointer ${
                    language === lang.code
                      ? 'language-btn-active'
                      : 'language-btn-inactive'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-6 pointer-events-auto flex-wrap">
            {navItems.map((item) => (
              <Link
                key={item.href}
                to={item.href}
                className="nav-link text-sm font-medium cursor-pointer"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;


