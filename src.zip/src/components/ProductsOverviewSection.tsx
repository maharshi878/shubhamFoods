import React from 'react';
import ScrollReveal from './ScrollReveal';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const products = [
  {
    id: 'black-garlic',
    route: '/products/black-garlic',
    name: 'Black Garlic',
    method: 'Controlled low-heat fermentation over multiple weeks',
    formats: 'Whole bulbs, peeled cloves, paste-ready lots',
  },
  {
    id: 'peeled-garlic',
    route: '/products/peeled-garlic',
    name: 'Peeled Garlic',
    method: 'Bulb breaking, peeling, washing, and controlled drying',
    formats: 'Fresh peeled cloves, bulk packs, retail-ready packs',
  },
  {
    id: 'freeze-dried',
    route: '/products/freeze-dried',
    name: 'Freeze Dried Products',
    method: 'Low-temperature dehydration for flavor and shelf stability',
    formats: 'Granules, powder, flakes, customized cuts',
  },
  {
    id: 'vacuum-fried',
    route: '/products/vacuum-fried',
    name: 'Vacuum Fried Products',
    method: 'Low-pressure frying for texture with controlled oil uptake',
    formats: 'Garlic chips, seasoned variants, private-label packs',
  },
  {
    id: 'roasted-masala',
    route: '/products/roasted-masala',
    name: 'Roasted Masala Garlic',
    method: 'Roasting and masala coating under batch control',
    formats: 'Snack packs, jars, foodservice pouches',
  },
];

const ProductsOverviewSection: React.FC = () => {
  return (
    <section id="products" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
      <div className="container px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <ScrollReveal>
              <span className="badge-research mb-6 inline-block">Products Overview</span>
            </ScrollReveal>
            <ScrollReveal delay={0.1}>
              <h2 className="section-title mb-6">Product Lines by Shubham Foods</h2>
            </ScrollReveal>
            <ScrollReveal delay={0.2}>
              <p className="section-subtitle mx-auto">
                Black Garlic remains our most detailed line. Other categories are represented with concise
                technical summaries for buyers and process teams.
              </p>
            </ScrollReveal>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <ScrollReveal key={product.id} delay={index * 0.08}>
                <Link
                  to={product.route}
                  className="glass-card p-8 h-full flex flex-col group cursor-pointer no-underline text-inherit hover:border-primary/40 transition-colors duration-300"
                >
                  <h3 className="font-display text-2xl font-semibold mb-4">{product.name}</h3>
                  <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">Processing method</p>
                  <p className="text-foreground/90 leading-relaxed mb-5">{product.method}</p>
                  <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">Formats available</p>
                  <p className="text-foreground/90 leading-relaxed mb-6">{product.formats}</p>
                  <div className="inline-flex items-center gap-2 text-sm font-medium text-primary group-hover:gap-3 transition-all duration-300 mt-auto">
                    View Details <ArrowRight className="w-4 h-4" />
                  </div>
                </Link>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductsOverviewSection;








