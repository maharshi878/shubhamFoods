import React from 'react';
import ScrollReveal from './ScrollReveal';
import { CheckCircle2 } from 'lucide-react';

const productDetails = [
  {
    id: 'peeled-garlic',
    name: 'Peeled Garlic',
    points: [
      'Processed through bulb breaker, peeling, washing, and controlled centrifugal drying.',
      'Suitable for horeca kitchens, processors, and repackers requiring clean garlic inputs.',
      'Supplied in chilled or ambient-compatible packs as per handling protocol.',
    ],
  },
  {
    id: 'freeze-dried',
    name: 'Freeze Dried Products',
    points: [
      'Low-temperature moisture removal for concentrated flavor and improved shelf life.',
      'Available as granules, powders, and flakes for seasoning and dry blend applications.',
      'Batch-level checks for moisture and particle consistency.',
    ],
  },
  {
    id: 'vacuum-fried',
    name: 'Vacuum Fried Products',
    points: [
      'Vacuum frying supports crisp texture at lower thermal stress than conventional frying.',
      'Can be supplied plain or seasoned for snack and ingredient use.',
      'Oil quality and post-fry handling are controlled for consistent output.',
    ],
  },
  {
    id: 'roasted-masala',
    name: 'Roasted Masala Garlic',
    points: [
      'Roasted garlic integrated with controlled spice blending and coating.',
      'Developed for ready-to-eat snacking and flavor-forward retail products.',
      'Custom spice intensity and pack sizes available for channel-specific needs.',
    ],
  },
];

const ProductDetailsSection: React.FC = () => {
  return (
    <section className="py-24 relative">
      <div className="container px-6">
        <div className="max-w-6xl mx-auto space-y-8">
          {productDetails.map((product, index) => (
            <ScrollReveal key={product.id} delay={index * 0.1}>
              <div id={product.id} className="glass-card p-8 md:p-10">
                <h3 className="font-display text-3xl font-semibold mb-6">{product.name}</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {product.points.map((point) => (
                    <div key={point} className="bg-secondary/30 rounded-xl p-5 border border-border/30">
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-primary mt-0.5" />
                        <p className="text-muted-foreground leading-relaxed">{point}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductDetailsSection;
