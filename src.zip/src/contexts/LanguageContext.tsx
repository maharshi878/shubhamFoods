import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'gu' | 'hi';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.about': 'About',
    'nav.science': 'Science',
    'nav.benefits': 'Benefits',
    'nav.nutrition': 'Nutrition',
    'nav.process': 'Process',
    'nav.comparison': 'Compare',
    'nav.recipes': 'Recipes',
    'nav.faq': 'FAQ',
  
    // Hero — Black Garlic page
    'hero.badge': 'Fermented Garlic — Single Ingredient',
    'hero.title': 'Black Garlic',
    'hero.subtitle': 'Slow-Fermented. Naturally Transformed.',
    'hero.description': 'Whole garlic bulbs, fermented under controlled heat and humidity over several weeks. No additives. No shortcuts. The result is a product with a distinct flavor profile and a studied nutritional composition.',
    'hero.cta': 'Explore the Science',
    'hero.stat1.value': '2x',
    'hero.stat1.label': 'Antioxidant Markers',
    'hero.stat2.value': '30+',
    'hero.stat2.label': 'Days Fermented',
    'hero.stat3.value': '100%',
    'hero.stat3.label': 'Natural Process',
  
    // About — Black Garlic
    'about.badge': 'What It Is',
    'about.title': 'Black Garlic',
    'about.p1': 'Black garlic is produced by holding whole garlic bulbs at controlled temperature and humidity for several weeks. The process triggers the Maillard reaction — a chemical transformation that darkens the cloves, softens their texture, and develops a flavor profile closer to balsamic or tamarind than raw garlic.',
    'about.p2': 'The fermentation process increases concentrations of S-allyl-cysteine (SAC), a water-soluble organosulfur compound, while reducing the allicin responsible for raw garlic\'s sharp bite. The result is a milder, more complex ingredient with a studied biochemical profile.',
    'about.p3': 'First developed commercially in Korea in the early 2000s, black garlic has since been adopted across professional kitchens and studied in nutritional research for its composition and bioactive compound content.',
  
    // Research
    'research.badge': 'Published Research',
    'research.title': 'Scientific Literature',
    'research.subtitle': 'Black garlic has been examined across multiple peer-reviewed studies. Findings vary by fermentation conditions, source material, and methodology — results should be interpreted in context.',
  
    // Citations
    'citation1.title': 'Antioxidant Activity',
    'citation1.finding': 'Laboratory analyses consistently show higher antioxidant marker readings in black garlic versus fresh garlic. The degree of increase varies by fermentation duration, temperature, and measurement method.',
    'citation1.source': 'Journal of Food Science, 2009',
    'citation1.doi': 'DOI: 10.1111/j.1750-3841.2009.01090.x',
  
    'citation2.title': 'Cardiovascular Markers',
    'citation2.finding': 'Controlled studies have observed improvements in LDL cholesterol and blood pressure in subjects supplementing with black garlic extract. Sample sizes are modest and further trials are warranted.',
    'citation2.source': 'Nutrition Research, 2014',
    'citation2.doi': 'DOI: 10.1016/j.nutres.2014.04.003',
  
    'citation3.title': 'Anti-Inflammatory Pathways',
    'citation3.finding': 'S-allyl-cysteine has shown measurable influence on inflammatory markers in cell culture studies. In vivo human data remains limited but directionally consistent.',
    'citation3.source': 'Molecules, 2017',
    'citation3.doi': 'DOI: 10.3390/molecules22060919',
  
    'citation4.title': 'Neuroprotective Properties',
    'citation4.finding': 'Animal model and cell culture studies suggest SAC may support neuronal protection under oxidative stress conditions. Human clinical data is preliminary.',
    'citation4.source': 'Neurochemical Research, 2018',
    'citation4.doi': 'DOI: 10.1007/s11064-018-2628-1',
  
    'citation5.title': 'Immune Modulation',
    'citation5.finding': 'Studies examining immune cell response to black garlic extract have shown measurable modulation in controlled settings. Population-level effects require broader clinical investigation.',
    'citation5.source': 'Clinical Nutrition, 2012',
    'citation5.doi': 'DOI: 10.1016/j.clnu.2012.01.002',
  
    'citation6.title': 'Cell-Level Studies',
    'citation6.finding': 'In vitro studies across multiple cell types have identified interactions with oxidative stress pathways. These findings inform ongoing research but do not constitute clinical claims.',
    'citation6.source': 'Food Chemistry, 2016',
    'citation6.doi': 'DOI: 10.1016/j.foodchem.2016.03.106',
  
    // Benefits
    'benefits.badge': 'Studied Properties',
    'benefits.title': 'What the Research Examines',
    'benefits.subtitle': 'Bioactive properties identified in peer-reviewed literature. Composition varies by fermentation conditions.',
  
    'benefit1.title': 'Antioxidant Compounds',
    'benefit1.desc': 'Measurably higher antioxidant marker activity than fresh garlic across multiple laboratory analyses.',
  
    'benefit2.title': 'Cardiovascular Research',
    'benefit2.desc': 'Studies have examined effects on LDL cholesterol and blood pressure with directionally positive findings.',
  
    'benefit3.title': 'Digestive Tolerance',
    'benefit3.desc': 'Reduced allicin content makes black garlic significantly gentler on the digestive system than raw garlic.',
  
    'benefit4.title': 'Immune Research',
    'benefit4.desc': 'Controlled studies have examined immune cell response to black garlic extract with measurable findings.',
  
    'benefit5.title': 'S-Allyl-Cysteine',
    'benefit5.desc': 'Fermentation increases SAC concentration — a water-soluble organosulfur compound with an established research profile.',
  
    'benefit6.title': 'Anti-Inflammatory Studies',
    'benefit6.desc': 'Cell-level studies show influence on inflammatory pathways. Human clinical trials are ongoing.',
  
    // Why Us
    'whyUs.badge': 'Our Approach',
    'whyUs.title': 'How We Make It',
    'whyUs.subtitle': 'Process discipline over volume. Consistency over shortcuts.',
  
    'whyUs.item1.title': 'Controlled Fermentation',
    'whyUs.item1.desc': 'Each batch is fermented under monitored temperature and humidity conditions for the full required duration. No acceleration.',
  
    'whyUs.item2.title': 'Single Ingredient',
    'whyUs.item2.desc': 'Whole garlic bulbs only. No additives, preservatives, or processing aids of any kind.',
  
    'whyUs.item3.title': 'Batch Inspection',
    'whyUs.item3.desc': 'Every batch is checked for color, texture, and consistency before it leaves the facility.',
  
    'whyUs.item4.title': 'Traceable Sourcing',
    'whyUs.item4.desc': 'Garlic is sourced from local regional growers and selected for variety and maturity suitability.',
  
    // Nutrition
    'nutrition.badge': 'Composition',
    'nutrition.title': 'Nutritional Profile',
    'nutrition.subtitle': 'Approximate values per 100g. Actual composition varies by fermentation duration, temperature, and source variety.',
    'nutrition.note': 'Data compiled from multiple published analyses. Values are directional — exact figures vary significantly across batches and studies.',
  
    // Process — Black Garlic specific
    'process.badge': 'Fermentation Process',
    'process.title': 'How Black Garlic Is Made',
    'process.subtitle': 'A slow, single-ingredient process. Temperature and humidity controlled throughout.',
  
    'process.step1.title': 'Bulb Selection',
    'process.step1.desc': 'Whole garlic bulbs are selected for size uniformity, skin integrity, and sugar content — all of which influence fermentation outcome.',
  
    'process.step2.title': 'Chamber Preparation',
    'process.step2.desc': 'Bulbs are placed in fermentation chambers calibrated to 80–90% relative humidity before the heat cycle begins.',
  
    'process.step3.title': 'Fermentation',
    'process.step3.desc': 'Held at 60–80°C for 30–40 days. The Maillard reaction and enzymatic activity transform the cloves — darkening color, softening texture, developing flavor.',
  
    'process.step4.title': 'Inspection and Packaging',
    'process.step4.desc': 'Finished bulbs are assessed for color uniformity and texture before packaging. No additives are introduced at any stage.',
  
    // Comparison
    'comparison.badge': 'Black vs Fresh',
    'comparison.title': 'How They Differ',
    'comparison.subtitle': 'Directional changes observed during fermentation. Exact values vary across studies and source material.',
    'comparison.nutrient': 'Component',
    'comparison.blackGarlic': 'Black Garlic',
    'comparison.freshGarlic': 'Fresh Garlic',
    'comparison.change': 'Direction',
    'comparison.lower': 'Reduced',
    'comparison.sac': 'S-Allyl-Cysteine',
    'comparison.polyphenols': 'Polyphenols',
    'comparison.antioxidant': 'Antioxidant Markers',
    'comparison.calories': 'Calories',
    'comparison.sugar': 'Natural Sugars',
    'comparison.allicin': 'Allicin',
    'comparison.note': 'Directional indicators only. Exact values vary significantly across batches, source material, and fermentation conditions.',
  
    // Recipes
    'recipes.badge': 'In the Kitchen',
    'recipes.title': 'Culinary Applications',
    'recipes.subtitle': 'Black garlic works across a wide range of applications — from condiments to glazes. Its mellow sweetness integrates without overpowering.',
    'recipes.ingredients': 'Key Ingredients',
    'recipes.minutes': 'min',
    'recipes.servings': 'servings',
    'recipes.easy': 'Easy',
    'recipes.medium': 'Medium',
    'recipes.hard': 'Advanced',
  
    'recipe1.name': 'Black Garlic Aioli',
    'recipe1.description': 'A rich, umami-forward aioli. Works as a spread, a dip, or a finishing sauce for grilled meats and roasted vegetables.',
    'recipe1.ingredients': 'Black garlic, egg yolks, olive oil, lemon juice, Dijon mustard',
  
    'recipe2.name': 'Black Garlic Pasta',
    'recipe2.description': 'Simple pasta dressed with black garlic, good olive oil, and aged Parmesan. The garlic melts into the sauce rather than asserting itself.',
    'recipe2.ingredients': 'Spaghetti, black garlic, pancetta, Parmesan, olive oil, fresh herbs',
  
    'recipe3.name': 'Black Garlic Butter',
    'recipe3.description': 'Compound butter with black garlic and thyme. Finishes steaks cleanly, works on bread, dissolves into pasta.',
    'recipe3.ingredients': 'Unsalted butter, black garlic, fresh thyme, sea salt',
  
    'recipe4.name': 'Black Garlic Glazed Salmon',
    'recipe4.description': 'Pan-seared salmon with a black garlic and honey glaze. The glaze caramelizes without bitterness.',
    'recipe4.ingredients': 'Salmon fillet, black garlic, honey, soy sauce, ginger, sesame oil',
  
    // FAQ
    'faq.badge': 'Common Questions',
    'faq.title': 'FAQ',
    'faq.subtitle': 'Storage, usage, taste, and sourcing — answered directly.',
  
    'faq.storage.question': 'How should black garlic be stored?',
    'faq.storage.answer': 'Unopened, store in a cool dry place away from direct light. Once opened, refrigerate and use within 2–3 months. Whole bulbs keep at room temperature for up to 30 days. Individual cloves can be frozen for up to 12 months without significant quality loss.',
  
    'faq.usage.question': 'How is black garlic used in cooking?',
    'faq.usage.answer': 'It can be used raw or cooked. Mash into sauces, dressings, and compound butters. Add to pasta, pizza, or risotto. Use as a glaze base for proteins. Its sweetness and depth work in both savory and sweet applications — it does not overpower the way raw garlic does.',
  
    'faq.taste.question': 'What does black garlic taste like?',
    'faq.taste.answer': 'Sweet, tangy, and savory — with notes of balsamic, tamarind, and molasses. None of the sharpness or bite of raw garlic. The texture is soft and spreadable, similar to a dried fig.',
  
    'faq.safety.question': 'Is black garlic safe for everyone?',
    'faq.safety.answer': 'Generally yes — it is gentler on digestion than raw garlic. Those on anticoagulant medication should consult a physician, as garlic products can enhance blood-thinning effects. Consume in moderation during pregnancy.',
  
    'faq.purchasing.question': 'What should I look for when buying black garlic?',
    'faq.purchasing.answer': 'Uniformly dark, glossy cloves with no white spots or visible mold. Texture should be soft but not mushy. Fermentation duration matters — 30–40 days produces optimal results. Avoid products that do not disclose fermentation time or source.',
  
    'faq.shelfLife.question': 'How long does black garlic last?',
    'faq.shelfLife.answer': 'Commercially packaged and unopened: 12–24 months. Once opened: up to 3 months refrigerated. Spoilage indicators are off odors and visible mold. When in doubt, discard.',
  
    // Footer
    'footer.tagline': 'A Product by Shubham Foods',
    'footer.desc': 'Single-ingredient fermented garlic. Controlled process. Consistent output.',
    'footer.disclaimer': 'Research citations are provided for informational purposes. This is not medical advice. Consult a qualified professional before making dietary or health decisions.',
    'footer.rights': '© 2025 Shubham Foods. All rights reserved.',
  },
  
  gu: {
    // Navigation
    'nav.about': 'વિશે',
    'nav.science': 'વિજ્ઞાન',
    'nav.benefits': 'ફાયદા',
    'nav.nutrition': 'પોષણ',
    'nav.process': 'પ્રક્રિયા',
    'nav.comparison': 'સરખામણી',
    'nav.recipes': 'વાનગીઓ',
    'nav.faq': 'FAQ',
    
    // Hero - Revised for accuracy
    'hero.badge': 'આથેલું કાર્યાત્મક ખોરાક',
    'hero.title': 'કાળું લસણ',
    'hero.subtitle': 'આથેલું ખજાનું',
    'hero.description': 'કેટલાક અઠવાડિયાઓની નિયંત્રિત આથવણી પ્રક્રિયા દ્વારા, સામાન્ય લસણ એક અનોખા રાંધણ ઘટકમાં રૂપાંતરિત થાય છે — વધુ મીઠું, હળવું, અને જૈવસક્રિય સંયોજનોથી સમૃદ્ધ.',
    'hero.cta': 'વિજ્ઞાન જાણો',
    'hero.stat1.value': '↑',
    'hero.stat1.label': 'એન્ટીઓક્સિડન્ટ્સ',
    'hero.stat2.value': '30+',
    'hero.stat2.label': 'દિવસ આથવણી',
    'hero.stat3.value': '100%',
    'hero.stat3.label': 'કુદરતી પ્રક્રિયા',
    
    // About
    'about.badge': 'મૂળ અને વિજ્ઞાન',
    'about.title': 'કાળું લસણ શું છે?',
    'about.p1': 'કાળું લસણ કેટલાક અઠવાડિયાઓમાં સમગ્ર લસણના બલ્બને ગરમ કરીને ઉત્પન્ન થાય છે — એક પ્રક્રિયા જેના પરિણામે નરમ, જેલી જેવી સુસંગતતા અને બાલ્સામિક સરકો અથવા આમલી જેવા સ્વાદ સાથે કાળા લવિંગ મળે છે.',
    'about.p2': 'આથવણી દરમિયાન મેઇલાર્ડ પ્રતિક્રિયા મેલાનોઇડિન્સ બનાવે છે જે તેના સિગ્નેચર ઘેરા રંગ માટે જવાબદાર છે જ્યારે S-allyl-cysteine (SAC) સામગ્રીમાં વધારો કરે છે.',
    'about.p3': '2000 ના દાયકાની શરૂઆતમાં કોરિયામાં પ્રથમ વિકસિત, કાળું લસણ રાંધણ ઘટક અને પોષણ સંશોધનના વિષય તરીકે લોકપ્રિય બન્યું છે.',
    
    // Research - Revised
    'research.badge': 'પ્રકાશિત અભ્યાસો',
    'research.title': 'વૈજ્ઞાનિક સંશોધન',
    'research.subtitle': 'કાળું લસણ તેની રચના અને સંભવિત સ્વાસ્થ્ય અસરોની તપાસ કરતા અસંખ્ય અભ્યાસોનો વિષય રહ્યું છે. પરિણામો અભ્યાસો અને શરતોમાં બદલાય છે.',
    
    // Citations - Revised
    'citation1.title': 'એન્ટીઓક્સિડન્ટ પ્રવૃત્તિ અભ્યાસો',
    'citation1.finding': 'પ્રયોગશાળા વિશ્લેષણ સૂચવે છે કે કાળું લસણ તાજા લસણની સરખામણીમાં વધુ એન્ટીઓક્સિડન્ટ પ્રવૃત્તિ દર્શાવે છે, જોકે ચોક્કસ મૂલ્યો આથવણીની સ્થિતિ પર આધાર રાખે છે.',
    'citation1.source': 'Journal of Food Science, 2009',
    'citation1.doi': 'DOI: 10.1111/j.1750-3841.2009.01090.x',
    
    'citation2.title': 'હૃદય સંબંધી સંશોધન',
    'citation2.finding': 'કેટલાક અભ્યાસોએ કોલેસ્ટ્રોલ માર્કર્સમાં સુધારો જોયો છે, જોકે સંશોધન મર્યાદિત છે અને મોટા ક્લિનિકલ ટ્રાયલ્સની જરૂર છે.',
    'citation2.source': 'Nutrition Research, 2014',
    'citation2.doi': 'DOI: 10.1016/j.nutres.2014.04.003',
    
    'citation3.title': 'બળતરા વિરોધી અભ્યાસો',
    'citation3.finding': 'સેલ કલ્ચર અભ્યાસો સૂચવે છે કે S-allyl-cysteine બળતરા માર્ગોને પ્રભાવિત કરી શકે છે. માનવ અભ્યાસો મર્યાદિત છે.',
    'citation3.source': 'Molecules, 2017',
    'citation3.doi': 'DOI: 10.3390/molecules22060919',
    
    'citation4.title': 'ન્યુરોપ્રોટેક્શન સંશોધન',
    'citation4.finding': 'પ્રયોગશાળા અભ્યાસો સંભવિત ન્યુરોપ્રોટેક્ટિવ ગુણધર્મો સૂચવે છે, મુખ્યત્વે સેલ કલ્ચર અને પ્રાણી મોડેલોમાં જોવા મળે છે.',
    'citation4.source': 'Neurochemical Research, 2018',
    'citation4.doi': 'DOI: 10.1007/s11064-018-2628-1',
    
    'citation5.title': 'રોગપ્રતિકારક કાર્ય અભ્યાસો',
    'citation5.finding': 'કેટલાક સંશોધન સંભવિત રોગપ્રતિકારક-મોડ્યુલેટિંગ અસરો સૂચવે છે. વધુ સંશોધનની જરૂર છે.',
    'citation5.source': 'Clinical Nutrition, 2012',
    'citation5.doi': 'DOI: 10.1016/j.clnu.2012.01.002',
    
    'citation6.title': 'સેલ કલ્ચર અભ્યાસો',
    'citation6.finding': 'ઇન વિટ્રો (પ્રયોગશાળા) અભ્યાસોએ વિવિધ સેલ પ્રકારો પર અસરોની તપાસ કરી છે. આ તારણો પ્રારંભિક છે.',
    'citation6.source': 'Food Chemistry, 2016',
    'citation6.doi': 'DOI: 10.1016/j.foodchem.2016.03.106',
    
    // Benefits - Revised
    'benefits.badge': 'સંભવિત ફાયદા',
    'benefits.title': 'રસના ક્ષેત્રો',
    'benefits.subtitle': 'પોષણ સંશોધનમાં અભ્યાસ કરવામાં આવતા ગુણધર્મો. વ્યક્તિગત પરિણામો બદલાઈ શકે છે.',
    
    'benefit1.title': 'શક્તિશાળી એન્ટીઓક્સિડન્ટ',
    'benefit1.desc': 'ફ્રી રેડિકલ્સને તટસ્થ કરે છે અને કોષીય સ્તરે ઓક્સિડેટિવ તણાવ ઘટાડે છે.',
    
    'benefit2.title': 'હૃદય સ્વાસ્થ્ય',
    'benefit2.desc': 'કોલેસ્ટ્રોલ પ્રોફાઇલ સુધારીને, બ્લડ પ્રેશર ઘટાડીને હૃદય કાર્યને સમર્થન આપે છે.',
    
    'benefit3.title': 'પાચન સ્વાસ્થ્ય',
    'benefit3.desc': 'કાચા લસણ કરતાં પેટ પર હળવું, સ્વસ્થ આંતરડાના બેક્ટેરિયાને પ્રોત્સાહન આપે છે.',
    
    'benefit4.title': 'રોગપ્રતિકારક સહાય',
    'benefit4.desc': 'કુદરતી કિલર સેલ પ્રવૃત્તિમાં વધારો કરે છે અને રોગપ્રતિકારક પ્રતિભાવને મોડ્યુલેટ કરે છે.',
    
    'benefit5.title': 'મગજ સુરક્ષા',
    'benefit5.desc': 'ન્યુરોપ્રોટેક્ટિવ સંયોજનો જ્ઞાનાત્મક કાર્ય જાળવવામાં મદદ કરે છે.',
    
    'benefit6.title': 'બળતરા વિરોધી',
    'benefit6.desc': 'દીર્ઘકાલીન બળતરા માર્કર્સ ઘટાડે છે, બળતરાની સ્થિતિના લક્ષણોમાં રાહત આપે છે.',
    
    // Why Us
    'whyUs.badge': 'શા માટે અમને પસંદ કરો',
    'whyUs.title': 'અમારું બ્લેક ગાર્લિક કેમ પસંદ કરશો',
    'whyUs.subtitle':
      'અમે પ્રક્રિયાની શુદ્ધતા, સરળ ઘટકો અને સતત ગુણવત્તા પર ધ્યાન આપીએ છીએ — વધારાના દાવાઓ પર નહીં.',

    'whyUs.item1.title': 'નિયંત્રિત ફર્મેન્ટેશન પ્રક્રિયા',
    'whyUs.item1.desc':
      'દરેક બેચને નિયંત્રિત પરિસ્થિતિઓમાં ફર્મેન્ટ કરવામાં આવે છે જેથી કુદરતી રૂપાંતર શક્ય બને, કોઈ શોર્ટકટ વિના.',

    'whyUs.item2.title': 'સરળ અને સંપૂર્ણ ઘટકો',
    'whyUs.item2.desc':
      'માત્ર સંપૂર્ણ લસણના કળીઓનો ઉપયોગ કરીને બનાવેલું, કોઈ ઉમેરા, પ્રિઝર્વેટિવ્સ અથવા કૃત્રિમ ઘટકો વિના.',

    'whyUs.item3.title': 'જથ્થા કરતાં ગુણવત્તા',
    'whyUs.item3.desc':
      'ઉત્પાદનની માત્રા કરતાં અમે દરેક બેચમાં ગુણવત્તા અને સતત તપાસને પ્રાથમિકતા આપીએ છીએ.',

    'whyUs.item4.title': 'પારદર્શક સંભાળ અને સોર્સિંગ',
    'whyUs.item4.desc':
      'સોર્સિંગ, સંગ્રહ અને હેન્ડલિંગ પ્રક્રિયાઓમાં પારદર્શિતા રાખીને વિશ્વાસ જાળવીએ છીએ.',

    // Nutrition
    'nutrition.badge': 'રચનાત્મક વિશ્લેષણ',
    'nutrition.title': 'પોષણ પ્રોફાઇલ',
    'nutrition.subtitle': 'કાળા લસણની 100g સર્વિંગ દીઠ, મુખ્ય જૈવસક્રિય સંયોજનો અને પોષણ મૂલ્યો.',
    'nutrition.note': 'આથવણીની સ્થિતિ અને લસણની વિવિધતાના આધારે મૂલ્યો બદલાઈ શકે છે.',
    
    // Process
    'process.badge': 'રૂપાંતરણ',
    'process.title': 'કેવી રીતે બને છે',
    'process.subtitle': 'એક ચોક્કસ, નિયંત્રિત આથવણી પ્રક્રિયા સામાન્ય લસણને અસાધારણ સુપરફૂડમાં રૂપાંતરિત કરે છે.',
    
    'process.step1.title': 'પસંદગી',
    'process.step1.desc': 'પ્રીમિયમ ગુણવત્તાવાળા સમગ્ર લસણના બલ્બને શ્રેષ્ઠ કદ, તાજગી અને ખાંડની સામગ્રી માટે કાળજીપૂર્વક પસંદ કરવામાં આવે છે.',
    
    'process.step2.title': 'તૈયારી',
    'process.step2.desc': 'બલ્બને સાફ કરવામાં આવે છે અને 80-90% સંબંધિત ભેજ જાળવીને નિયંત્રિત ભેજ ચેમ્બરમાં મૂકવામાં આવે છે.',
    
    'process.step3.title': 'આથવણી',
    'process.step3.desc': 'તાપમાન 30-40 દિવસ માટે 60-80°C પર જાળવવામાં આવે છે, મેઇલાર્ડ પ્રતિક્રિયા અને એન્ઝાઇમેટિક બ્રાઉનિંગને ટ્રિગર કરે છે.',
    
    'process.step4.title': 'પૂર્ણતા',
    'process.step4.desc': 'તૈયાર કાળું લસણ ટૂંકમાં વૃદ્ધ થાય છે, ગુણવત્તા માટે પરીક્ષણ કરવામાં આવે છે, અને તાજગી જાળવવા માટે પેક કરવામાં આવે છે.',
    
    // Comparison
    'comparison.badge': 'પોષક વિશ્લેષણ',
    'comparison.title': 'કાળું vs તાજું લસણ',
    'comparison.subtitle': 'એક બાજુ-બાજુની સરખામણી આથવણી દરમિયાન થતા નોંધપાત્ર રૂપાંતરણને દર્શાવે છે.',
    'comparison.nutrient': 'પોષક તત્વ',
    'comparison.blackGarlic': 'કાળું લસણ',
    'comparison.freshGarlic': 'તાજું લસણ',
    'comparison.change': 'ફેરફાર',
    'comparison.lower': 'ઓછું',
    'comparison.sac': 'S-Allyl-Cysteine',
    'comparison.polyphenols': 'પોલીફેનોલ્સ',
    'comparison.antioxidant': 'એન્ટીઓક્સિડન્ટ ક્ષમતા',
    'comparison.calories': 'કેલરી',
    'comparison.sugar': 'કુદરતી ખાંડ',
    'comparison.allicin': 'એલિસિન',
    'comparison.note': '100g સર્વિંગ દીઠ મૂલ્યો. એન્ટીઓક્સિડન્ટ ક્ષમતા ORAC એકમોમાં માપવામાં આવે છે.',
    
    // Recipes
    'recipes.badge': 'રાંધણ પ્રેરણા',
    'recipes.title': 'વાનગી વિચારો',
    'recipes.subtitle': 'તમારી રાંધણ કળામાં કાળા લસણનો સમાવેશ કરવાની સ્વાદિષ્ટ રીતો શોધો.',
    'recipes.ingredients': 'મુખ્ય ઘટકો',
    'recipes.minutes': 'મિનિટ',
    'recipes.servings': 'સર્વિંગ',
    'recipes.easy': 'સરળ',
    'recipes.medium': 'મધ્યમ',
    'recipes.hard': 'અદ્યતન',
    
    'recipe1.name': 'કાળા લસણની આયોલી',
    'recipe1.description': 'સેન્ડવીચ, ગ્રિલ્ડ મીટ, અથવા સોફિસ્ટિકેટેડ ડિપિંગ સોસ તરીકે ઉત્તમ ઉમામી-ભરપૂર આયોલી.',
    'recipe1.ingredients': 'કાળું લસણ, ઈંડાની જરદી, ઓલિવ ઓઇલ, લીંબુનો રસ, ડિજોન મસ્ટર્ડ',
    
    'recipe2.name': 'કેરામેલાઇઝ્ડ કાળા લસણની પાસ્તા',
    'recipe2.description': 'મીઠા કેરામેલાઇઝ્ડ કાળા લસણ, ક્રિસ્પી પેન્સેટા અને એજ્ડ પાર્મેસન સાથે સિલ્કી પાસ્તા.',
    'recipe2.ingredients': 'સ્પાઘેટી, કાળું લસણ, પેન્સેટા, પાર્મેસન, ઓલિવ ઓઇલ, તાજી હર્બ્સ',
    
    'recipe3.name': 'કાળા લસણનું કમ્પાઉન્ડ બટર',
    'recipe3.description': 'સ્ટેક પર ફિનિશ કરવા અથવા આર્ટિઝન બ્રેડ પર ફેલાવવા માટે ઉત્તમ લક્ઝરિયસ બટર.',
    'recipe3.ingredients': 'અનસોલ્ટેડ બટર, કાળું લસણ, તાજું થાઇમ, દરિયાઈ મીઠું',
    
    'recipe4.name': 'ગ્લેઝ્ડ કાળા લસણની સૅલ્મન',
    'recipe4.description': 'ચળકતી કાળા લસણ અને મધની ગ્લેઝ સાથે પેન-સિયર્ડ સૅલ્મન, સીઝનલ શાકભાજી સાથે પીરસવામાં આવે છે.',
    'recipe4.ingredients': 'સૅલ્મન ફિલેટ, કાળું લસણ, મધ, સોયા સોસ, આદુ, તલનું તેલ',
    
    // FAQ
    'faq.badge': 'સામાન્ય પ્રશ્નો',
    'faq.title': 'વારંવાર પૂછાતા પ્રશ્નો',
    'faq.subtitle': 'કાળા લસણ વિશે તમારે જાણવાની જરૂર છે તે બધું — સંગ્રહથી રાંધણ ઉપયોગો સુધી.',
    
    'faq.storage.question': 'કાળા લસણને કેવી રીતે સંગ્રહિત કરવું?',
    'faq.storage.answer': 'કાળા લસણને ઠંડી, અંધારી જગ્યાએ હવાચુસ્ત કન્ટેનરમાં સંગ્રહિત કરો. ખોલ્યા પછી, રેફ્રિજરેટ કરો અને 2-3 મહિનામાં વાપરો. આખા બલ્બ ઓરડાના તાપમાને 30 દિવસ સુધી રાખી શકાય છે. લાંબા ગાળાના સંગ્રહ માટે, 12 મહિના સુધી વ્યક્તિગત લવિંગને ફ્રીઝ કરી શકો છો.',
    
    'faq.usage.question': 'રસોઈમાં કાળા લસણનો ઉપયોગ કેવી રીતે કરવો?',
    'faq.usage.answer': 'કાળા લસણનો કાચો અથવા રાંધેલો ઉપયોગ કરી શકાય છે. સોસ, સ્પ્રેડ અને ડ્રેસિંગમાં મેશ કરો. પાસ્તા, પિઝા અથવા રિસોટ્ટોમાં ઉમેરો. મીટ માટે ગ્લેઝ તરીકે વાપરો અથવા મેરિનેડમાં સામેલ કરો.',
    
    'faq.taste.question': 'કાળા લસણનો સ્વાદ કેવો હોય છે?',
    'faq.taste.answer': 'કાળા લસણમાં જટિલ સ્વાદ પ્રોફાઇલ છે — મીઠું, ખાટું અને સ્વાદિષ્ટ, બાલ્સામિક સરકો, આમલી અને ગોળની નોંધો સાથે. તાજા લસણથી વિપરીત, તેમાં કોઈ તીખો અથવા મસાલેદાર સ્વાદ નથી.',
    
    'faq.safety.question': 'શું કાળું લસણ બધા માટે સલામત છે?',
    'faq.safety.answer': 'કાળું લસણ મોટાભાગના લોકો માટે સામાન્ય રીતે સલામત છે અને કાચા લસણ કરતાં પાચન તંત્ર પર હળવું છે. જો કે, લોહી પાતળું કરતી દવાઓ લેતા લોકોએ તેમના ડૉક્ટરની સલાહ લેવી જોઈએ.',
    
    'faq.purchasing.question': 'કાળું લસણ ખરીદતી વખતે શું જોવું?',
    'faq.purchasing.answer': 'સમાન રીતે ઘેરા, ચળકતા લવિંગવાળા કાળા લસણ શોધો. સફેદ ધબ્બા અથવા ફૂગવાળા ઉત્પાદનો ટાળો. ગુણવત્તાયુક્ત કાળું લસણ નરમ પણ મશગુલ ન હોવું જોઈએ. શક્ય હોય ત્યારે ઓર્ગેનિક પસંદ કરો.',
    
    'faq.shelfLife.question': 'કાળું લસણ કેટલો સમય ટકે છે?',
    'faq.shelfLife.answer': 'બંધ, વ્યાપારી રીતે પેક કરેલું કાળું લસણ 12-24 મહિના ટકી શકે છે. ખોલ્યા પછી, રેફ્રિજરેટ કરેલું હોય ત્યારે 3 મહિનામાં વાપરો. ઘરે બનાવેલું કાળું લસણ ઓરડાના તાપમાને 1 મહિનામાં અથવા રેફ્રિજરેટેડ 3 મહિનામાં વાપરવું જોઈએ.',
    
    // Footer
    'footer.tagline': 'પ્રીમિયમ કાળું લસણ',
    'footer.desc': 'કુદરતના સૌથી શક્તિશાળી સુપરફૂડને અનલૉક કરવા માટે આથવણીની શક્તિનો ઉપયોગ કરવો.',
    'footer.disclaimer': 'આ માહિતી ફક્ત શૈક્ષણિક હેતુઓ માટે છે. આહારમાં ફેરફાર કરતા પહેલા આરોગ્ય વ્યાવસાયિકોની સલાહ લો.',
    'footer.rights': '© 2024 કાળું લસણ કેટલોગ. સર્વાધિકાર સુરક્ષિત.',
  },
  
  hi: {
    // Navigation
    'nav.about': 'परिचय',
    'nav.science': 'विज्ञान',
    'nav.benefits': 'लाभ',
    'nav.nutrition': 'पोषण',
    'nav.process': 'प्रक्रिया',
    'nav.comparison': 'तुलना',
    'nav.recipes': 'व्यंजन',
    'nav.faq': 'FAQ',
    
    // Hero - Revised
    'hero.badge': 'किण्वित कार्यात्मक खाद्य',
    'hero.title': 'काला लहसुन',
    'hero.subtitle': 'किण्वित खजाना',
    'hero.description': 'कई हफ्तों की नियंत्रित किण्वन प्रक्रिया के माध्यम से, साधारण लहसुन एक अनोखी पाक सामग्री में बदल जाता है — मीठा, हल्का, और जैव सक्रिय यौगिकों से समृद्ध।',
    'hero.cta': 'विज्ञान जानें',
    'hero.stat1.value': '↑',
    'hero.stat1.label': 'एंटीऑक्सीडेंट',
    'hero.stat2.value': '30+',
    'hero.stat2.label': 'दिन किण्वन',
    'hero.stat3.value': '100%',
    'hero.stat3.label': 'प्राकृतिक प्रक्रिया',
    
    // About
    'about.badge': 'उत्पत्ति और विज्ञान',
    'about.title': 'काला लहसुन क्या है?',
    'about.p1': 'काला लहसुन कई हफ्तों में पूरे लहसुन के बल्बों को गर्म करके उत्पादित किया जाता है — एक प्रक्रिया जिसके परिणामस्वरूप नरम, जेली जैसी स्थिरता और बाल्सामिक सिरका या इमली जैसे स्वाद वाली काली कलियाँ बनती हैं।',
    'about.p2': 'किण्वन के दौरान मेलार्ड प्रतिक्रिया मेलानोइडिन बनाती है जो इसके विशिष्ट गहरे रंग के लिए जिम्मेदार है जबकि S-allyl-cysteine (SAC) सामग्री में वृद्धि करती है।',
    'about.p3': '2000 के दशक की शुरुआत में कोरिया में पहली बार विकसित, काला लहसुन पाक सामग्री और पोषण अनुसंधान के विषय के रूप में लोकप्रिय हुआ है।',
    
    // Research - Revised
    'research.badge': 'प्रकाशित अध्ययन',
    'research.title': 'वैज्ञानिक अनुसंधान',
    'research.subtitle': 'काले लहसुन की संरचना और संभावित स्वास्थ्य प्रभावों की जांच करने वाले कई अध्ययनों का विषय रहा है। परिणाम अध्ययनों में भिन्न होते हैं।',
    
    // Citations - Revised
    'citation1.title': 'एंटीऑक्सीडेंट गतिविधि अध्ययन',
    'citation1.finding': 'प्रयोगशाला विश्लेषण सुझाव देते हैं कि काला लहसुन ताजे लहसुन की तुलना में अधिक एंटीऑक्सीडेंट गतिविधि दिखाता है, हालांकि सटीक मान किण्वन स्थितियों पर निर्भर करते हैं।',
    'citation1.source': 'Journal of Food Science, 2009',
    'citation1.doi': 'DOI: 10.1111/j.1750-3841.2009.01090.x',
    
    'citation2.title': 'हृदय संबंधी अनुसंधान',
    'citation2.finding': 'कुछ अध्ययनों में कोलेस्ट्रॉल मार्करों में सुधार देखा गया है, हालांकि शोध सीमित है और बड़े नैदानिक परीक्षणों की आवश्यकता है।',
    'citation2.source': 'Nutrition Research, 2014',
    'citation2.doi': 'DOI: 10.1016/j.nutres.2014.04.003',
    
    'citation3.title': 'सूजन-रोधी अध्ययन',
    'citation3.finding': 'सेल कल्चर अध्ययन सुझाव देते हैं कि S-allyl-cysteine सूजन मार्गों को प्रभावित कर सकता है। मानव अध्ययन सीमित हैं।',
    'citation3.source': 'Molecules, 2017',
    'citation3.doi': 'DOI: 10.3390/molecules22060919',
    
    'citation4.title': 'न्यूरोप्रोटेक्शन अनुसंधान',
    'citation4.finding': 'प्रयोगशाला अध्ययन संभावित न्यूरोप्रोटेक्टिव गुणों का सुझाव देते हैं, मुख्य रूप से सेल कल्चर और पशु मॉडल में देखे गए।',
    'citation4.source': 'Neurochemical Research, 2018',
    'citation4.doi': 'DOI: 10.1007/s11064-018-2628-1',
    
    'citation5.title': 'प्रतिरक्षा कार्य अध्ययन',
    'citation5.finding': 'कुछ शोध संभावित प्रतिरक्षा-मॉड्यूलेटिंग प्रभावों का सुझाव देते हैं। अधिक शोध की आवश्यकता है।',
    'citation5.source': 'Clinical Nutrition, 2012',
    'citation5.doi': 'DOI: 10.1016/j.clnu.2012.01.002',
    
    'citation6.title': 'सेल कल्चर अध्ययन',
    'citation6.finding': 'इन विट्रो (प्रयोगशाला) अध्ययनों ने विभिन्न सेल प्रकारों पर प्रभावों की जांच की है। ये निष्कर्ष प्रारंभिक हैं।',
    'citation6.source': 'Food Chemistry, 2016',
    'citation6.doi': 'DOI: 10.1016/j.foodchem.2016.03.106',
    
    // Benefits - Revised
    'benefits.badge': 'संभावित लाभ',
    'benefits.title': 'रुचि के क्षेत्र',
    'benefits.subtitle': 'पोषण अनुसंधान में अध्ययन किए जा रहे गुण। व्यक्तिगत परिणाम भिन्न हो सकते हैं।',
    
    'benefit1.title': 'एंटीऑक्सीडेंट सामग्री',
    'benefit1.desc': 'प्रयोगशाला सेटिंग्स में फ्री रेडिकल्स को निष्क्रिय करने में मदद कर सकने वाले एंटीऑक्सीडेंट गुणों वाले यौगिक होते हैं।',
    
    'benefit2.title': 'हृदय स्वास्थ्य',
    'benefit2.desc': 'कोलेस्ट्रॉल प्रोफाइल में सुधार करके, रक्तचाप कम करके हृदय कार्य का समर्थन करता है।',
    
    'benefit3.title': 'पाचन स्वास्थ्य',
    'benefit3.desc': 'कच्चे लहसुन की तुलना में पेट पर हल्का, स्वस्थ आंत बैक्टीरिया को बढ़ावा देता है।',
    
    'benefit4.title': 'प्रतिरक्षा सहायता',
    'benefit4.desc': 'प्राकृतिक किलर सेल गतिविधि को बढ़ाता है और प्रतिरक्षा प्रतिक्रिया को मॉड्यूलेट करता है।',
    
    'benefit5.title': 'मस्तिष्क सुरक्षा',
    'benefit5.desc': 'न्यूरोप्रोटेक्टिव यौगिक संज्ञानात्मक कार्य बनाए रखने में मदद करते हैं।',
    
    'benefit6.title': 'सूजन-रोधी',
    'benefit6.desc': 'पुरानी सूजन मार्करों को कम करता है, सूजन की स्थिति के लक्षणों से राहत देता है।',
    
    // Why Us
    'whyUs.badge': 'हमें क्यों चुनें',
    'whyUs.title': 'हमारा ब्लैक गार्लिक क्यों चुनें',
    'whyUs.subtitle':
      'हम प्रक्रिया की ईमानदारी, सरल सामग्री और निरंतर गुणवत्ता पर ध्यान देते हैं — बढ़ा-चढ़ाकर किए गए दावों पर नहीं।',

    'whyUs.item1.title': 'नियंत्रित किण्वन प्रक्रिया',
    'whyUs.item1.desc':
      'प्रत्येक बैच को नियंत्रित परिस्थितियों में किण्वित किया जाता है ताकि प्राकृतिक परिवर्तन बिना किसी शॉर्टकट के हो सके।',

    'whyUs.item2.title': 'सरल और पूर्ण सामग्री',
    'whyUs.item2.desc':
      'केवल साबुत लहसुन की कलियों से तैयार, बिना किसी एडिटिव, प्रिज़र्वेटिव या कृत्रिम पदार्थ के।',

    'whyUs.item3.title': 'मात्रा से अधिक गुणवत्ता',
    'whyUs.item3.desc':
      'हम उत्पादन की मात्रा के बजाय प्रत्येक बैच की गुणवत्ता और निरंतर निरीक्षण को प्राथमिकता देते हैं।',

    'whyUs.item4.title': 'पारदर्शी हैंडलिंग और सोर्सिंग',
    'whyUs.item4.desc':
      'सोर्सिंग, भंडारण और हैंडलिंग प्रक्रियाओं में पारदर्शिता रखकर उपभोक्ता का भरोसा बनाए रखते हैं।',

    // Nutrition
    'nutrition.badge': 'संरचनात्मक विश्लेषण',
    'nutrition.title': 'पोषण प्रोफाइल',
    'nutrition.subtitle': 'काले लहसुन की 100g सर्विंग प्रति, प्रमुख जैव सक्रिय यौगिक और पोषण मूल्य।',
    'nutrition.note': 'किण्वन की स्थिति और लहसुन की किस्म के आधार पर मूल्य भिन्न हो सकते हैं।',
    
    // Process
    'process.badge': 'रूपांतरण',
    'process.title': 'कैसे बनता है',
    'process.subtitle': 'एक सटीक, नियंत्रित किण्वन प्रक्रिया साधारण लहसुन को असाधारण सुपरफूड में बदल देती है।',
    
    'process.step1.title': 'चयन',
    'process.step1.desc': 'प्रीमियम गुणवत्ता वाले पूरे लहसुन के बल्बों को इष्टतम आकार, ताजगी और चीनी सामग्री के लिए सावधानीपूर्वक चुना जाता है।',
    
    'process.step2.title': 'तैयारी',
    'process.step2.desc': 'बल्बों को साफ किया जाता है और 80-90% सापेक्ष आर्द्रता बनाए रखते हुए नियंत्रित आर्द्रता कक्षों में रखा जाता है।',
    
    'process.step3.title': 'किण्वन',
    'process.step3.desc': 'तापमान 30-40 दिनों के लिए 60-80°C पर बनाए रखा जाता है, मेलार्ड प्रतिक्रिया और एंजाइमेटिक ब्राउनिंग को ट्रिगर करता है।',
    
    'process.step4.title': 'पूर्णता',
    'process.step4.desc': 'तैयार काले लहसुन को संक्षेप में पुराना किया जाता है, गुणवत्ता के लिए परीक्षण किया जाता है, और ताजगी बनाए रखने के लिए पैक किया जाता है।',
    
    // Comparison
    'comparison.badge': 'पोषक विश्लेषण',
    'comparison.title': 'काला vs ताजा लहसुन',
    'comparison.subtitle': 'एक साथ-साथ तुलना किण्वन के दौरान होने वाले उल्लेखनीय परिवर्तन को दर्शाती है।',
    'comparison.nutrient': 'पोषक तत्व',
    'comparison.blackGarlic': 'काला लहसुन',
    'comparison.freshGarlic': 'ताजा लहसुन',
    'comparison.change': 'परिवर्तन',
    'comparison.lower': 'कम',
    'comparison.sac': 'S-Allyl-Cysteine',
    'comparison.polyphenols': 'पॉलीफेनोल्स',
    'comparison.antioxidant': 'एंटीऑक्सीडेंट क्षमता',
    'comparison.calories': 'कैलोरी',
    'comparison.sugar': 'प्राकृतिक शर्करा',
    'comparison.allicin': 'एलिसिन',
    'comparison.note': '100g सर्विंग प्रति मूल्य। एंटीऑक्सीडेंट क्षमता ORAC इकाइयों में मापी गई।',
    
    // Recipes
    'recipes.badge': 'पाक प्रेरणा',
    'recipes.title': 'व्यंजन विचार',
    'recipes.subtitle': 'अपनी पाक कला में काले लहसुन को शामिल करने के स्वादिष्ट तरीके खोजें।',
    'recipes.ingredients': 'मुख्य सामग्री',
    'recipes.minutes': 'मिनट',
    'recipes.servings': 'सर्विंग',
    'recipes.easy': 'आसान',
    'recipes.medium': 'मध्यम',
    'recipes.hard': 'उन्नत',
    
    'recipe1.name': 'काले लहसुन की आयोली',
    'recipe1.description': 'सैंडविच, ग्रिल्ड मीट, या एक परिष्कृत डिपिंग सॉस के रूप में उत्कृष्ट उमामी-भरपूर आयोली।',
    'recipe1.ingredients': 'काला लहसुन, अंडे की जर्दी, जैतून का तेल, नींबू का रस, डिजोन मस्टर्ड',
    
    'recipe2.name': 'कैरामेलाइज्ड काले लहसुन की पास्ता',
    'recipe2.description': 'मीठे कैरामेलाइज्ड काले लहसुन, क्रिस्पी पंचेटा और एज्ड परमेसन के साथ सिल्की पास्ता।',
    'recipe2.ingredients': 'स्पेगेटी, काला लहसुन, पंचेटा, परमेसन, जैतून का तेल, ताजी जड़ी-बूटियाँ',
    
    'recipe3.name': 'काले लहसुन का कंपाउंड बटर',
    'recipe3.description': 'स्टेक पर फिनिश करने या आर्टिसन ब्रेड पर फैलाने के लिए उत्कृष्ट लक्जरी बटर।',
    'recipe3.ingredients': 'अनसाल्टेड बटर, काला लहसुन, ताजा थाइम, समुद्री नमक',
    
    'recipe4.name': 'ग्लेज्ड काले लहसुन की सैल्मन',
    'recipe4.description': 'चमकदार काले लहसुन और शहद ग्लेज़ के साथ पैन-सियर्ड सैल्मन, मौसमी सब्जियों के साथ परोसा गया।',
    'recipe4.ingredients': 'सैल्मन फ़िलेट, काला लहसुन, शहद, सोया सॉस, अदरक, तिल का तेल',
    
    // FAQ
    'faq.badge': 'सामान्य प्रश्न',
    'faq.title': 'अक्सर पूछे जाने वाले प्रश्न',
    'faq.subtitle': 'काले लहसुन के बारे में आपको जो कुछ जानना चाहिए — भंडारण से लेकर पाक उपयोग तक।',
    
    'faq.storage.question': 'काले लहसुन को कैसे स्टोर करें?',
    'faq.storage.answer': 'काले लहसुन को ठंडी, अंधेरी जगह में एयरटाइट कंटेनर में स्टोर करें। खोलने के बाद, रेफ्रिजरेट करें और 2-3 महीने में उपयोग करें। पूरे बल्ब कमरे के तापमान पर 30 दिनों तक रखे जा सकते हैं। लंबी अवधि के भंडारण के लिए, 12 महीने तक व्यक्तिगत कलियों को फ्रीज कर सकते हैं।',
    
    'faq.usage.question': 'खाना पकाने में काले लहसुन का उपयोग कैसे करें?',
    'faq.usage.answer': 'काले लहसुन का कच्चा या पका हुआ उपयोग किया जा सकता है। सॉस, स्प्रेड और ड्रेसिंग में मैश करें। पास्ता, पिज्जा या रिसोट्टो में जोड़ें। मीट के लिए ग्लेज़ के रूप में उपयोग करें या मैरिनेड में शामिल करें।',
    
    'faq.taste.question': 'काले लहसुन का स्वाद कैसा होता है?',
    'faq.taste.answer': 'काले लहसुन में जटिल स्वाद प्रोफ़ाइल है — मीठा, खट्टा और स्वादिष्ट, बाल्सामिक सिरका, इमली और गुड़ की नोट्स के साथ। ताजे लहसुन के विपरीत, इसमें कोई तीखा या मसालेदार स्वाद नहीं है।',
    
    'faq.safety.question': 'क्या काला लहसुन सभी के लिए सुरक्षित है?',
    'faq.safety.answer': 'काला लहसुन अधिकांश लोगों के लिए आम तौर पर सुरक्षित है और कच्चे लहसुन की तुलना में पाचन तंत्र पर हल्का है। हालांकि, रक्त पतला करने वाली दवाएं लेने वालों को अपने डॉक्टर से परामर्श करना चाहिए।',
    
    'faq.purchasing.question': 'काला लहसुन खरीदते समय क्या देखें?',
    'faq.purchasing.answer': 'समान रूप से गहरी, चमकदार कलियों वाला काला लहसुन देखें। सफेद धब्बे या फफूंद वाले उत्पादों से बचें। गुणवत्ता वाला काला लहसुन नरम होना चाहिए लेकिन गीला नहीं। जब संभव हो जैविक चुनें।',
    
    'faq.shelfLife.question': 'काला लहसुन कितने समय तक रहता है?',
    'faq.shelfLife.answer': 'बंद, व्यावसायिक रूप से पैक किया गया काला लहसुन 12-24 महीने तक चल सकता है। खोलने के बाद, रेफ्रिजरेटेड होने पर 3 महीने के भीतर उपयोग करें। घर का बना काला लहसुन कमरे के तापमान पर 1 महीने या रेफ्रिजरेटेड 3 महीने में उपयोग करना चाहिए।',
    
    // Footer
    'footer.tagline': 'प्रीमियम काला लहसुन',
    'footer.desc': 'प्रकृति के सबसे शक्तिशाली सुपरफूड को अनलॉक करने के लिए किण्वन की शक्ति का उपयोग करना।',
    'footer.disclaimer': 'यह जानकारी केवल शैक्षिक उद्देश्यों के लिए है। आहार में बदलाव करने से पहले स्वास्थ्य पेशेवरों से परामर्श करें।',
    'footer.rights': '© 2024 काला लहसुन कैटलॉग। सर्वाधिकार सुरक्षित।',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
